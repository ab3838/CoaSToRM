fmesh = 'dambreak_310x83_sbn1x1.nc' ; 
feta = 'Eta.nc' ;

nx = 310 ;
ny = 83 ; 

bz = ncread( fmesh, 'sbzcell' ) ; 
bz = reshape( -bz, ny, nx ) ;
bz( bz > 1 ) = 0.65 ; 

bz1 = zeros( 85, 312 ) + 0.25 ; 
bz1(2:end-1,2:end-1) = bz ; 

x = ncread( feta, 'x' ) ; 
y = ncread( feta, 'y' ) ; 
tt = ncread( feta, 'tt' ) ;

[xx,yy] = meshgrid(x,y) ; 

figure('Position',[200 200 800 500]) ;
v = [-2.5 35 -2.5 7.5 0 1] ;
for it = 1: length(tt)
   clf ;
   eta = ncread( feta, 'eta', [1 1 it], [ (ny + 2) (nx + 2) 1]) ; 
   h = ncread( feta, 'h', [1 1 it], [ (ny + 2) (nx + 2) 1]) ;
   
   idx = find( eta > 1 ) ; 
   eta( idx ) = 0.61 ;  
   
   surf( xx, yy, eta ) ;
   view([0.7,-0.8,1]) ;
   daspect([1 1 0.25]) ;
   axis(v) ; caxis([0 0.2]) ;
   shading('interp') ;
   camlight ; 
   
   xlabel('x') ; 
   ylabel('y') ; 
   str = sprintf('tt = %8.5f', tt(it) )  ;
   title( str ) ; drawnow ; 
   set( gcf, 'color', 'w' ) ; 
   
   fname = ['eta_snap' sprintf('%03d',it) '.jpg'] ;
   export_fig( fname, '-jpg' ) ; 
end


