function grd_slope_channel() 

% nx = [124  248  496 1240] ;
% ny = [10    20  40   100] ;
% nx = [25 50 100 200 400] ; 
% ny = nx ;
nx = [310 310] ;
ny = [83  166]  ; 

% Do not change this
x1 = 0 ; x2 = 31  ;
y1 = 0 ; y2 = 8.3 ;

Lx = (x2 - x1) ;
Ly = (y2 - y1) ;

%--- Pre-compute bathymetric depth at the subgrid level
fnbath = @bathchannel ;

% Subgrid mesh size
dsx = 0.1 ;
dsy = 0.1 ; 

rnday = 2/24 ; % final time (in days) 
dt = 1 ; % second

genmeshflag = 1 ; 
if ( genmeshflag )
    %
    for i  = 2: length(nx) % 1: length(nx)
        % [zgd,~,~] = makestaggeredgrid( nx(i), ny(i) ) ;
        dx = Lx/nx(i) ;
        dy = Ly/ny(i) ;
        
        msnx = ceil(dx/dsx) ;
        msny = ceil(dy/dsy)  ;
        
        ncfile = sprintf('dambreak_%dx%d_sbn%dx%d.nc', nx(i), ny(i), msnx, msny ) ;
        if ( ~exist(ncfile,'file') )
            cretencsubgrid( ncfile, 1, [nx(i) ny(i)], [msnx msny] ) ;
        end
       
        % Locations of cells 
        x = x1 + ([1:nx(i)] - 0.5)*dx ;
        y = y1 + ([1:ny(i)] - 0.5)*dy ;
        
        % Write coordinates
        ncwrite( ncfile, 'x', x ) ;
        ncwrite( ncfile, 'y', y ) ;
        
        for ii = 1: nx(i)
            xb = x(ii) - dx/2 ;
            xs = xb + ([1:msnx] - 0.5)*dsx ;
            
            % %
            for jj = 1: ny(i)
                yb = y(jj) - dy/2 ;
                ys = yb + ([1:msny] - 0.5)*dsy ;
                
                [xxs,yys] = meshgrid(xs,ys) ;
                bxy = fnbath( xxs, yys ) ;
                
                % Add ns(1:2,iy,ix)  - dimension of subgrid
                ncwrite( ncfile, 'ns', [msnx msny]', [1 jj ii] ) ;
                
                % Add bsz => sbzcell(1:msn(2),1:msn(1),iy,ix) - subgrid bathymetric depth
                ncwrite( ncfile, 'sbzcell', bxy, [1 1 jj ii]) ;
            end
            % %
            
        end
        % Create boundary file
        [xx,yy] = meshgrid(x,y) ; 
        bxy = fnbath( xx, yy ) ; 
        
        surf(xx, yy, bxy ) ;  drawnow ;
    end
end

geninitflag = 1 ; 
if ( geninitflag )
    % ns = (rnday*d2sec/dt) ; 
    
    for i = 1: length(nx) %1: length(nx) 
        dx = Lx/nx(i) ;
        dy = Ly/ny(i) ;
        
        zicfile = sprintf('dambreak_%dx%d_zeta0.dat', nx(i), ny(i) ) ;
        uicfile = sprintf('dambreak_%dx%d_u0.dat', nx(i), ny(i) ) ;
        vicfile = sprintf('dambreak_%dx%d_v0.dat', nx(i), ny(i) ) ;
        
        [zgd,ugd,vgd] = makestaggeredgrid( nx(i), ny(i) ) ;
        
        % zeta - surface elevation
        zgd.xx = x1 + zgd.xx*Lx ;
        zgd.yy = y1 + zgd.yy*Ly ;
        zsol = getdambreakinit( zgd.xx, zgd.yy, 'zeta' ) ;
        
        fid = fopen( zicfile, 'w') ;
        msg = 'Initial condition : zeta' ;
        write_header( fid, msg, nx(i), ny(i) ) ;
        write_data( fid, zsol, nx(i), ny(i) ) ;
        fclose(fid) ;
        
        % u - velocity
        ugd.xx = x1 + ugd.xx*Lx ;
        ugd.yy = y1 + ugd.yy*Ly ;
        usol = getdambreakinit( ugd.xx, ugd.yy, 'u' ) ;
        fid = fopen( uicfile, 'w' ) ;
        msg = 'Initial condition : u' ;
        write_header( fid, msg, nx(i) + 1, ny(i) ) ;
        write_data( fid, usol, nx(i) + 1, ny(i) ) ;
        fclose(fid) ;
        
        % v - velocity
        vgd.xx = x1 + vgd.xx*Lx ;
        vgd.yy = y1 + vgd.yy*Ly ;
        vsol = getdambreakinit( vgd.xx, vgd.yy, 'v' ) ;
        fid = fopen( vicfile, 'w' ) ;
        msg = 'Initial condition : v' ;
        write_header( fid, msg, nx(i), ny(i) + 1 ) ;
        write_data( fid, vsol, nx(i), ny(i) + 1 ) ;
        fclose(fid) ;
        
      
    end 
end

   
% %%%%%%%%%%%%%%%%%%%%%% Sub functions 
    function write_header( fid, msg, nx, ny )
        fprintf( fid, '%s\n', msg ) ; 
        fprintf( fid, '%d %d\n', nx, ny )  ;
    end

    function write_data( fid, sol, nx, ny )
        fprintf( fid, '%18.9e \n', sol ) ;
    end


end