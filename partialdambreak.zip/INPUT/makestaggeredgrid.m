function [zgd,ugd,vgd] = makestaggeredgrid( NX, NY )
% 
% Create 2D staggered C-Grid on [0,1]x[0,1] 
%
dx = 1/NX ;
dy = 1/NY ; 


% Cell-center
x = ([1:NX] - 0.5)*dx ; 
y = ([1:NY] - 0.5)*dy ; 

[xx,yy] = meshgrid(x,y) ;
zgd.xx = xx ; 
zgd.yy = yy ;

% u-grid
x = ([1:(NX + 1)] - 1)*dx ; 
y = ([1:NY] - 0.5)*dy ; 

[xx,yy] = meshgrid(x,y) ;
ugd.xx = xx ;
ugd.yy = yy ; 

% v-grid
x = ([1:NX] - 0.5)*dx ;
y = ([1:(NY + 1)] - 1)*dy ; 

[xx,yy] = meshgrid(x,y) ;
vgd.xx = xx ;
vgd.yy = yy ; 
