function soln = getdambreakinit( xx, yy, var )

switch ( lower(strtrim(var)) )
    case ('zeta')
        dh = 0.1 ;
        
        soln = xx*0 ;
        idx = find( xx < (8.0 - dh) ) ;
        if ( ~isempty(idx) )
            soln(idx) = 0.6 ;
        end
        
        
    case ('u')
        soln = xx*0 ;
    case ('v')
        soln = xx*0 ;
end

end