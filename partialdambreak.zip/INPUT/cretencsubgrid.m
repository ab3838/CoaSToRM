function [] = cretencsubgrid( ncfile, istg, nx, mns, ftype )
% 
% Create NETCDF file, define dimensions, variables to be used 
% in a subgrid program. No data is filled. 
%
%   ncfile -- name of a NETCDF file to be created
%   istg   -- subgrid integration schem
%             1 - mid point rule (prefered)
%             2 - trapzodial rule 
%   nx(2)  -- [N_{x},N_{y}]   grid resolution ( N_{x} X N_{y} cell)
%   msx(2) -- [N_{sx},N_{sx}] subgrid resolution of each mesh cell
%   ftype  -- Type of input file to be create
%             1 -- cell data, N_{x}xN_{Y} cell, each cell contains
%                  a subgrida data [N_{sx},N_{}]
%  
%             2 -- vertical edge   -- needed when using a lookup table
%                                     to determine the volume at 
%                                     cell interface
%             3 -- horizontal edge -- needed when using a lookup table 
%                                     
% by DW
%
%
netcdfinfo.Name = '/' ;
netcdfinfo.Format = 'classic' ;

netcdfinfo.Attributes(1).Name = 'istg' ;
netcdfinfo.Attributes(1).Value = istg ;

netcdfinfo.Attributes(2).Name = 'sbgrdtype' ; 
netcdfinfo.Attributes(2).Value = 'cell' ; 
if ( nargin  > 4 )
    if ( ftype == 1 ) 
       netcdfinfo.Attributes(2).Value = 'cell' ; 
    elseif ( ftype == 2 ) 
       netcdfinfo.Attributes(2).Value = 'edge_u' ;
    elseif ( ftype == 3 )
       netcdfinfo.Attributes(2).Value = 'edge_v' ;
    end
end
 
%
% Define dimension names
%
netcdfinfo.Dimensions(1).Name = 'nx' ;
netcdfinfo.Dimensions(1).Length = nx(1) ;

netcdfinfo.Dimensions(2).Name = 'ny' ;
netcdfinfo.Dimensions(2).Length = nx(2) ;

% istg = 1, 2, subgrid bathymetry (msnx,msny)
% istg = 11, 12, look-up table bathymetry, msnx = table resolution, msny = 3
netcdfinfo.Dimensions(3).Name = 'msnx' ;
netcdfinfo.Dimensions(3).Length = mns(1) ;

netcdfinfo.Dimensions(4).Name = 'msny' ;
netcdfinfo.Dimensions(4).Length = mns(2) ;

netcdfinfo.Dimensions(5).Name = 'dim2' ; 
netcdfinfo.Dimensions(5).Length = 2 ;

netcdfinfo.Dimensions(6).Name = 'dim3' ; 
netcdfinfo.Dimensions(6).Length = 3 ;
%
% netcdfinfo.Dimensions(5).Name = 'time' ;
% netcdfinfo.Dimensions(5).Length = Inf ;
%

%
% (x,y) -- location of the cell
netcdfinfo.Variables(4).Name = 'x' ;
netcdfinfo.Variables(4).Dimensions(1) = netcdfinfo.Dimensions(1) ; % nx
netcdfinfo.Variables(4).Datatype = 'double' ;

netcdfinfo.Variables(5).Name = 'y' ;
netcdfinfo.Variables(5).Dimensions(1) = netcdfinfo.Dimensions(2) ; % ny
netcdfinfo.Variables(5).Datatype = 'double' ;

%  dim(ns) = [2, NY, NX]
%      Intended for stotring the subgrid dimension of each cell
netcdfinfo.Variables(1).Name = 'ns' ;
netcdfinfo.Variables(1).Dimensions(1) = netcdfinfo.Dimensions(5) ; % 2
netcdfinfo.Variables(1).Dimensions(2) = netcdfinfo.Dimensions(2) ; % ny
netcdfinfo.Variables(1).Dimensions(3) = netcdfinfo.Dimensions(1) ; % nx
netcdfinfo.Variables(1).Datatype = 'int32' ;

%
% dim(bzm) = [3, NY, NX]
% (needed in the loop up table)
%        bzm(1,J,I) - minimum value of bathymetric depth of cell I,J  
%        bzm(2,J,I) - maximum 
%        bzm(3,J,I) - mean
%
netcdfinfo.Variables(2).Name = 'bzm' ;
netcdfinfo.Variables(2).Dimensions(1) = netcdfinfo.Dimensions(6) ; % 3
netcdfinfo.Variables(2).Dimensions(2) = netcdfinfo.Dimensions(2) ; % ny
netcdfinfo.Variables(2).Dimensions(3) = netcdfinfo.Dimensions(1) ; % nx
netcdfinfo.Variables(2).Datatype = 'double' ;

% Subgrid data in either in grided data or a look-up table 
% dim(sbzcell) = [N_{sy},N_{sx},N_{y},N_{x}]
%       sbzcell(:,:,J,I) - subgrid data of the (I,J)-cell 
netcdfinfo.Variables(3).Name = 'sbzcell' ;
netcdfinfo.Variables(3).Dimensions(1) = netcdfinfo.Dimensions(4) ; % msny (sy or 3 \eta, V (A), A (L) )
netcdfinfo.Variables(3).Dimensions(2) = netcdfinfo.Dimensions(3) ; % msnx (sx or a table look-up resolution) 
netcdfinfo.Variables(3).Dimensions(3) = netcdfinfo.Dimensions(2) ; % ny
netcdfinfo.Variables(3).Dimensions(4) = netcdfinfo.Dimensions(1) ; % nx
netcdfinfo.Variables(3).Datatype = 'double' ;

%
ncwriteschema( strtrim(ncfile), netcdfinfo ) ;
