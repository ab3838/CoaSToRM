function [hz] = bathchannel( xx, yy ) 
%
h0 = 0 ;

hz = xx*0 + h0 ;

dh = 0.1 ;

idx = find( xx >= (8.0 - dh) & xx <= (8.0 +  dh) & ...
    (yy <= (4.15 - 0.2) | yy >= (4.15 + 0.2)) ) ; 

if ( ~isempty(idx) ) 
    hz(idx) = 2 ;
end


% hz(yy <= 75 & yy >= 25) = h0 ;
%
%xc = [20 20 20] ;
%yc = [30 50 70]  ;
%
%for i = 1: length(xc)
%    rr = sqrt((xx - xc(i)).^2 + (yy - yc(i)).^2) ;
%    idx = find( rr <= 2 ) ;
% if ( ~isempty(idx) )
%     hz(idx) = 20 ;
% end
% end
% 
% slp = 1/5 ;
% 
% idx = find( yy <= 25 ) ;
% if ( ~isempty(idx) )
%     hz(idx) = -slp*yy(idx) + 1 ;
% end
% 
% idx = find( yy >= 75 ) ;
% if ( ~isempty(idx) )
%     hz(idx) = slp*(yy(idx) - 75) + h0 ;
% end

% bathmetry positive downward
hz = -hz ; 
